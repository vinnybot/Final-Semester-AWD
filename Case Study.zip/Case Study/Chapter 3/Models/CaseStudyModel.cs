﻿using System.ComponentModel.DataAnnotations;
namespace Chapter_3.Models
{
    public class CaseStudyModel
    {
    }
}
