﻿namespace Chapter_3.Models
{
    public class Country
    {
        public string CountryId { get; set; } = string.Empty;

        public string Name { get; set; } = string.Empty;
    }
}
