﻿namespace PIG.Models
{
    public class Player
    {
        public string Name { get; set; } = String.Empty;
        public int Score { get; set; }
    }
}
